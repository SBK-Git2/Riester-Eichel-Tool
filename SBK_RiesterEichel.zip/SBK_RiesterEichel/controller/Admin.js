sap.ui.define(["sap/ui/model/json/JSONModel","sap/m/MessageToast"], function(JM,MessageToast) {
	"use strict";
	return {
		Init: function(that) {
			this.GlobalThis = that;
			this.AdminData = {
				configParams: []
			};
			that.AdminControl = {};
			that.getView().setModel(new JM(this.AdminData, true), "ADMIN");			
		},
		onAdminModePress: function(oEvent) {
			var that = this;
			if (!that.AdminControl.Dialog) {
				sap.ui.require([
						"sap/m/Dialog",
						"sap/ui/richtexteditor/RichTextEditor", "sap/ui/richtexteditor/EditorType",
						'sap/ui/model/Filter', "sap/ui/model/FilterOperator",
						"sap/m/DatePicker", "sap/m/StepInput", "sap/m/Button", "sap/m/Label", "sap/m/FormattedText",
						"sap/m/Select", "sap/ui/core/Item", "sap/ui/core/CustomData", "sap/m/ActionSheet", "sap/m/HBox"
					],
					function(Dialog, RTE, EditorType, Filter, FilterOperator, DatePicker, StepInput, Button, Label, FormattedText, Select, Item,
						CustomData,ActionSheet, HBox) {
						that.AdminControl = {
							
							
							ParamLabel :new Label({
									design: "Bold",
									text: "Parameter-Wert: "
								}).addStyleClass("sapUiMediumMarginEnd")
							,
							StepInput: new StepInput({
								visible: true,
								textAlign: "Center",
								//width: "20%",
								editable: true,
								min: 0,
								max: 30,
								description: ""
							}),
							DatePicker: new DatePicker({
								visible: false,
								textAlign: "Center",
								//width: "20%",
								value: "2020-12-01",
								valueFormat: "dd.MM",
								displayFormat: "dd.MM"
							}),
							RTE: new RTE("RTE", {
								editable: true,
								visible: true,
								editorType: "TinyMCE4",
								width: "100%",
								height: "auto",
								customToolbar: true,
								showGroupFont: true,
								showGroupLink: true,
								showGroupInsert: false,
								showGroupClipboard: true,
								showGroupUndo: true,
								value: "",
								ready: function() {
									this.addButtonGroup("styleselect").addButtonGroup("table");
								},
								customButtons: [
								//	new Button({
								//		text: that.oI18n.getText("PARAMS"),
								//		type: "Emphasized",
								//		press: that.ADM.onEditorTextButtonPress,
								//		dependents: [new ActionSheet({
								//			placement: "Bottom",
								//			buttons: {
								//				path: "/configParams",
								//				filters: [new Filter({
								//					path: 'ParamType',
								//					operator: FilterOperator.EQ,
								//					value1: 'EDITOR'
								//				})],
								//				template: new Button({
								//					text: "{text}",
								//					press: that.ADM.EditorTEXT,
								//					customData: [new CustomData({
								//				key: "KEY",
								//				value: "{ParamName}",
								//				writeToDom: false
								//			})]
								//				}), 
								//				templateSharable: true
								//			}
								//		})]
								//	}),
									new Button({
										tooltip: that.oI18n.getText("BACKUP"),
										icon: "sap-icon://upload-to-cloud",
										type: "Transparent",
										press: function() {
											var oDialog = this.getParent().getParent().getParent().getParent(),
												FileName = that.AdminControl.ParamSelect.getSelectedKey() + "-" + new Date().toISOString() + ".txt",
												textValue = that.AdminControl.oDialog.getModel().getData().TEXTS[oDialog.getContent()[0].getSelectedKey()];
											that.ADM.downloadHtmlFile(textValue, FileName, "text");
										}
									})
								]

							}),
							ParamSelect: new Select({
								textAlign: "Center",
								//selectedKey: "{/selectedParam/ParamValue}",
								visible: true,
								forceSelection: true,
								change: function(oItem) {
									var ParameterPath = that.AdminControl.ParamSelect.getSelectedItem().getBindingContext().getPath(),
										ParameterInfo = that.getView().getModel("ADMIN").getProperty(ParameterPath) ;
									that.getView().getModel("ADMIN").setProperty("/selectedParam", ParameterInfo);

									that.AdminControl.StepInput.unbindProperty("value");
									that.AdminControl.DatePicker.unbindProperty("dateValue");
									that.AdminControl.RTE.unbindProperty("value");

									if (ParameterInfo.ParamType === "NUMBER") {
										that.AdminControl.ParamLabel.setVisible(true);
										that.AdminControl.StepInput.setVisible(true);
										that.AdminControl.DatePicker.setVisible(false);										
										that.AdminControl.RTE.setEditable(false);
										//that.AdminControl.StepInput.setValue(parseInt(ParameterInfo.ParamValue, 10));
										//that.getView().getModel("ADMIN").setProperty(ParameterPath + "/ParamValue", parseInt(ParameterInfo.ParamValue, 10));
										that.AdminControl.StepInput.bindProperty("value", {
												path: ParameterPath + "/ParamValue",
												type: new sap.ui.model.type.Integer(),
												mode: sap.ui.model.BindingMode.TwoWay });
										

									} else if (ParameterInfo.ParamType === "DATE") {
										that.AdminControl.ParamLabel.setVisible(true);
										that.AdminControl.DatePicker.setVisible(true);
										that.AdminControl.StepInput.setVisible(false);
										that.AdminControl.RTE.setEditable(false);
										//that.AdminControl.DatePicker.setDateValue(new Date(ParameterInfo.ParamValue));
										//that.getView().getModel("ADMIN").setProperty(ParameterPath + "/ParamValue", new Date(ParameterInfo.ParamValue));
										that.AdminControl.DatePicker.bindProperty("dateValue", {
												path: ParameterPath + "/ParamValue",
												//type: new sap.ui.model.type.Date(),
												mode: sap.ui.model.BindingMode.TwoWay });
																				
									} else {
										that.AdminControl.RTE.setEditable(true);										
										that.AdminControl.DatePicker.setVisible(false);
										that.AdminControl.StepInput.setVisible(false);
										that.AdminControl.ParamLabel.setVisible(false);
										//that.AdminControl.RTE.setValue(ParameterInfo.ParamValue);
										that.AdminControl.RTE.bindProperty("value", {
												path: ParameterPath + "/ParamValue",
												type: new sap.ui.model.type.String(),
												mode: sap.ui.model.BindingMode.TwoWay });
									}
								},
								items: {
									path: "/configParams"
									//,filters: [new Filter({
									//	path: 'ParamType',
									//	operator: FilterOperator.NE,
									//	value1: 'EDITOR'
									//})]
									,
									template: new Item({
										key: "{ParamName}",
										text: "{text}"
									}),
									templateSharable: true
								}
							})
						};
						that.AdminControl.Dialog = new Dialog({
							stretch: true,
							resizable: true,
							draggable: true,
							showHeader: true,
							state: "Warning",
							contentHeight: "auto",
							verticalScrolling: true,
							title: that.oI18n.getText("ADMIN"),
							beginButton: new Button({
								type: "Accept",
								text: that.oI18n.getText("SAVE"),
								press: that.ADM.onSaveDialog,
								customData: [new CustomData({
									key: "_",
									value: that,
									writeToDom: false
								})]
							}),
							endButton: new Button({
								text: that.oI18n.getText("CLOSE"),
								press: that.ADM.onCloseDialog
							}),
								customData: [new CustomData({
									key: "_",
									value: that,
									writeToDom: false
								})],
							content: [new HBox({
								justifyContent: "Center",
								alignItems: "Center",
								items: [new Label({
									design: "Bold",
									text: "Parameter: "
								}).addStyleClass("sapUiMediumMarginEnd"), that.AdminControl.ParamSelect]
							}).addStyleClass("sapUiLargeMarginBottom"), new HBox({
								justifyContent: "Center",
								alignItems: "Center",
								items: [that.AdminControl.ParamLabel, that.AdminControl.DatePicker, that.AdminControl.StepInput]
							}).addStyleClass("sapUiMediumMarginBottom"), that.AdminControl.RTE]
						});
						that.AdminControl.Dialog.setModel(that.getOwnerComponent().getModel("i18n"), "i18n");
						that.AdminControl.Dialog.setModel(that.getView().getModel("ADMIN"));
						that.AdminControl.Dialog.open();
						that.AdminControl.ParamSelect.fireEvent("change");
					}.bind(this));
			} else {
				that.AdminControl.Dialog.open();
				that.AdminControl.ParamSelect.fireEvent("change");
			}

		},
		onSaveDialog: function(oEvt) {
			let _ = this.getCustomData()[0].getValue();
			var AppData = _.getView().getModel("ADMIN").getData().configParams;
			var updateData = [];
		   _.configParamsBackup.forEach(function(C, idx) {
			   var value = AppData[idx].ParamValue;
			   if (C.ParamType === "DATE" ){
					value = sap.ui.core.format.DateFormat.getDateInstance({pattern:"yyyyMMdd"}).format(value);
				}
                if (value !== C.ParamValue) {
                    updateData.push({
                        MANDT: '',
                        PARAM_NAME: C.ParamName,
                        PARAM_TYPE: C.ParamType,
                        SPRAS: C.Spras,
                        PARAM_VALUE: value,
                        FLAG: 'X'
                    });
                }

            });
		if (updateData.length > 0){
			_.getView().getModel().callFunction("/SAVE_CONFIGS", {
				urlParameters: {"DATA":JSON.stringify(updateData) },
				success: function(R) {
					MessageToast.show(_.oI18n.getText("MSG_SAVED"));
				},
				error: function(E) {
					sap.m.MessageToast.show(E.message);
					
				}
			});
		}
		},
		onCloseDialog: function(oEvt) {
			oEvt.getSource().getParent().close();
		},
		EditorTEXT: function() {
			var oDialog = this.getParent().getParent().getParent().getParent().getParent().getParent().getParent(),
			Key = this.getCustomData()[0].getValue(),
			that = oDialog.getCustomData()[0].getValue(),
			oParams = oDialog.getModel().getData().configParams;
			oDialog.getContent()[2].setValue(that._getConfigParamValue(Key));
			that.AdminControl.TextKey = Key;
			//oDialog.getContent()[0].setSelectedKey());
		},
		onEditorTextButtonPress: function() {
			this.getDependents()[0].openBy(this);
		},
		downloadHtmlFile: function(data, filename, type) {
			let file = new Blob([data], {
				type: type
			});
			if (window.navigator.msSaveOrOpenBlob) // IE10+
				window.navigator.msSaveOrOpenBlob(file, filename);
			else { // Others
				let a = document.createElement("a"),
					url = URL.createObjectURL(file);
				a.href = url;
				a.download = filename;
				document.body.appendChild(a);
				a.click();
				setTimeout(function() {
					document.body.removeChild(a);
					window.URL.revokeObjectURL(url);
				}, 0);
			}
		}

	};
});