sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment",
	"ZHR_RIESTER_EICHEL/controller/Admin",
	'sap/ui/core/message/Message',
	'sap/ui/core/MessageType',
	'sap/m/MessagePopover',
	'sap/m/MessageItem',
	'sap/ui/core/Core',
], function(Controller, JM, MessageToast, MessageBox, Fragment, Admin, Message, MessageType,MessagePopover, MessageItem,Core) {
	"use strict";

	return Controller.extend("ZHR_RIESTER_EICHEL.controller.Main", {
		ADM: Admin,
		GlobalData: {},
		FormInfo: {},
		modelDataBackup: {},
		LastTab: "",
		messages: [],
		onInit: function() {
			var that = this;
			this.getView().setBusy(true);
			this.ADM.Init(this);

			this.oI18n = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			that.getView().setBusy(true);
			jQuery.sap.require("sap.ui.core.theming.Parameters");
			this._MessageManager = Core.getMessageManager();
			this.getView().setModel(this._MessageManager.getMessageModel(), "message");
			this.getView().setModel(new JM(this.messages, true), "ERROR");
			this.oCurrencyFormat =sap.ui.core.format.NumberFormat.getCurrencyInstance({
			"currencyCode": true,
			"showMeasure": true, 
			"groupingEnabled": true, 
			"groupingSize": 3, 
			"decimals": 2,
			"emptyString": 0,
			"groupingSeparator":".",
			"decimalSeparator":","
		});
		this.oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			pattern: 'dd.MM.yyyy'
		});

			this.GlobalData = {
				BusyMode: true,
				DataFound: true,
				SelectedTab: "INFO",
				TotalColor: sap.ui.core.theming.Parameters.get("sapField_InformationColor"),
				Mode: "M", //Papiervotum 
				CHANGE_DATE: null,
				BLOCKED_MONTH: 4,
				CURRENCY: "€",
				EmployeeInfo: {
					"NAME": "",
					"POSITION_TEXT": "",
					"GROUP": "T", //AVWL
					"ONBEHLAF": ""
				},
				REISTER_VOTUMSOPTION: [{
					"code": "1",
					"text": "Maximalbetrag monatlich verteilt"
				}, {
					"code": "2",
					"text": "Maximalbetrag monatlich verteilt (Summe=Maximalbetrag)"
				}, {
					"code": "3",
					"text": "Monatlicher Festbetrag"
				}, {
					"code": "4",
					"text": "manuelle Einzelbeträge"
				}]
			};
			this.RenteShareInfo = {
				SUBTYPE: "",
				HEADER_HTML: "",
				FOOTER_HTML: "",
				VERTRAG_NUMBER: "",
				TABLE_DATA: [],
				AVWL: false,
				AVWL_DATE: new Date(),
				AVWL_ACTIVE: true,
				SEL_BETRAG_KEY: "1",
				CHK_BERUF: false,
				CHK_HINTER: false,
				RDIO_JAHR: 0,
				KALENDAR_JAHR: ""
			};
			this.getView().setModel(new JM(this.GlobalData, true), "Global");
			this.getView().setModel(new JM(this.RenteShareInfo, true), "Rente");

			this.oDataModel = this.getView().getModel();
			if (!this.oDataModel) {
				this.oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_HR_RE_SRV");
			}

			this._getReisterEichelData();

			this.oDataModel.read("/ConfigSet", {
				filters: [],
				urlParameters: {},
				success: function(R) {
					var oConfigData = R.results;

					var configParams = [],
						FilterContext = oConfigData.filter(a => a.ParamType !== 'CONTEXT');
					for (let p of FilterContext) {
						if (p.ParamType === "DATE") {
							p.ParamValue = p.ParamValue.substr(0, 4) + "-" + p.ParamValue.substr(4, 2) + "-" + p.ParamValue.substr(6, 2);
							p.ParamValue = new Date(p.ParamValue);
						}
						configParams.push({
							ParamName: p.ParamName,
							ParamType: p.ParamType,
							text: that.oI18n.getText(p.ParamName),
							ParamValue: p.ParamValue,
							Spras: p.Spras
						});
					}
					that.configParamsBackup = JSON.parse(JSON.stringify(configParams));
					that.getView().getModel("ADMIN").setProperty("/configParams", configParams);
					that.getView().setModel(new JM(oConfigData, true), "CONFIG");
					that.FormInfo.INFO_HEADER = that._getConfigParamValue("INFO_HEADER_HTML");
					that.FormInfo.INFO_FOOTER = that._getConfigParamValue("INFO_FOOTER_HTML");
					that.RenteShareInfo.HEADER_HTML = that.FormInfo.INFO_HEADER;
					that.RenteShareInfo.FOOTER_HTML = that.FormInfo.FOOTER_HTML;
					var sFormModel = that.getView().getModel("FormInfo");
					if (sFormModel) {
						sFormModel.setProperty("/INFO_HEADER", that.FormInfo.INFO_HEADER);
						sFormModel.setProperty("/FOOTER_HTML", that.FormInfo.FOOTER_HTML);
					}

					that.GlobalData.BusyMode = false;
					if (that._getConfigParamValue("USER_MODE") !== 'ADM') {
						that.getView().byId("AdminButton").setVisible(false);
					}
					that.getView().setBusy(false);
				},
				error: function(E) {
					if (E) {
						var tmp = document.createElement("DIV");
						tmp.innerHTML = E.response.body;
						MessageToast.show(tmp.textContent || tmp.innerText || "");
					} else {
						MessageToast.show(that.oI18n.getText("ErrorData"));
					}
					that.GlobalData.DataFound = false;
					that.GlobalData.BusyMode = false;
					that.getView().byId("NotFound").setVisible(true);
					that.getView().byId("Tabs").setVisible(false);
					that.getView().byId("AdminButton").setVisible(false);
					that.getView().setBusy(false);
				}
			});
			
		},
		_getReisterEichelData: function() {
			var that = this;
			this.oDataModel.read("/RiesterEichelSet", {
				filters: [],
				urlParameters: {},
				success: function(R) {
					that.getView().setModel(new JM(R.results, true), "EMPLOYEE");
					var oEmployeeModelData = R.results;
					that.oEmployeeModelDataBackup = JSON.parse(JSON.stringify(oEmployeeModelData));
					that.FormInfo = {
						VOTESFORDE: oEmployeeModelData.filter(V => V.Subtype === '0010'),
						VOTESCOMFORT: oEmployeeModelData.filter(V => V.Subtype === '0020'),
						COMFORT: oEmployeeModelData.filter(V => V.Subtype == '0020' && V.Flag2 == 'true')[0],
						FORDER: oEmployeeModelData.filter(V => V.Subtype == '0010' && V.Flag2 == 'true')[0],
						INFO_HEADER: "",
						INFO_FOOTER: "",
						FORDER_TAB: [],
						COMFORT_TAB: []
					};
					that.FormInfo.FORDER_TAB = that._StrucConvertToTable(that.FormInfo.FORDER);
					that.FormInfo.COMFORT_TAB = that._StrucConvertToTable(that.FormInfo.COMFORT);
					if (!that.FormInfo.FORDER) {
						that.getView().byId("Tabs").getItems()[1].setEnabled(false);
					}
					if (!that.FormInfo.COMFORT) {
						that.getView().byId("Tabs").getItems()[2].setEnabled(false);
					}
					that.FormInfo.INFO_HEADER = that._getConfigParamValue("INFO_HEADER_HTML");
					that.FormInfo.INFO_FOOTER = that._getConfigParamValue("INFO_FOOTER_HTML");
					that.getView().setModel(new JM(that.FormInfo, true), "FormInfo");
					that.GlobalData.BusyMode = false;
					that.getView().setBusy(false);
				},
				error: function(E) {
					if (E && E.response && E.response.body) {											
						var data = that.xmlToJson(new DOMParser().parseFromString(E.response.body, 'text/xml'))
						.error.innererror.errordetails.errordetail;
						if (Array.isArray(data)){
							MessageToast.show(data[0].message);														
						}else{
							MessageToast.show(data.message);
						}
					} else {
						MessageToast.show(that.oI18n.getText("ErrorData"));
					}
					
					that.GlobalData.BusyMode = false;
					that.GlobalData.DataFound = false;
					that.getView().byId("NotFound").setVisible(true);
					that.getView().byId("Tabs").setVisible(false);
					that.getView().byId("AdminButton").setVisible(false);
					that.getView().setBusy(false);
				}
			});
		},
		_getConfigParamValue: function(Param) {
			var oConfModel = this.getView().getModel("CONFIG");
			if (oConfModel && oConfModel.getData().length > 0) {
				var Data = JSON.parse(JSON.stringify(oConfModel.getData()));
				return Data.filter(C => C.ParamName === Param)[0].ParamValue;
			} else {
				return "";
			}
		},
		formatInfoIcon: function(V){
			if (V === true || V === 'true'){
				return 'sap-icon://accept';
			}if (V === false || V === 'false'){
				return 'sap-icon://decline';
			}else{
				return "";
				}
		},
		onVotumInput: function(oEvent) {
			let sum = 0;
			for (let i = 0; i < 12; i++) {
				sum = Number(sum) + Number(this.RenteShareInfo.TABLE_DATA[i].VOTUM);
			}
			this.RenteShareInfo.TABLE_DATA[12].VOTUM = sum.toFixed(3);
			this.getView().getModel("Rente").setProperty("/TABLE_DATA/12/VOTUM", sum.toFixed(3));
		},
		onAfterRendering: function() {},
		onTabSelect: function(oEvent) {
			this.updateRenteData(oEvent.getSource().getSelectedKey());
		},
		updateRenteData: function(TabSelected) {
			this.RenteShareInfo.HEADER_HTML = this._getConfigParamValue(TabSelected + "_HEADER_HTML");
			this.RenteShareInfo.FOOTER_HTML = this._getConfigParamValue(TabSelected + "_FOOTER_HTML");
			this.RenteShareInfo.KALENDAR_JAHR = this._getConfigParamValue("CALENDAR_YEAR");
			var sRenteModel = this.getView().getModel("Rente");
			if (sRenteModel) {
				sRenteModel.setProperty("/HEADER_HTML", this.RenteShareInfo.HEADER_HTML);
				sRenteModel.setProperty("/FOOTER_HTML", this.RenteShareInfo.FOOTER_HTML);
			}
			if (TabSelected === "INFO" || !this.FormInfo[TabSelected]) {
				this.LastTab = TabSelected;
				this.RenteShareInfo = {
					SUBTYPE: "",
					HEADER_HTML: "",
					FOOTER_HTML: "",
					VERTRAG_NUMBER: "",
					TABLE_DATA: [],
					AVWL: false,
					SEL_BETRAG_KEY: "1",
					CHK_BERUF: false,
					CHK_HINTER: false,
					RDIO_JAHR: 0,
					KALENDAR_JAHR: ""
				}
				sRenteModel.setData(this.RenteShareInfo);
				return; // No Update to Shared Model Needed
			}
			if (TabSelected === this.LastTab) {
				sRenteModel.setData(this.RenteShareInfo);
				return;
			}
			var FormInfo = JSON.parse(JSON.stringify(this.FormInfo[TabSelected]));
			if (this.LastTab && this.LastTab !== "" && this.LastTab !== "INFO" && this.LastTab !== TabSelected && this.FormInfo[this.LastTab]) {
				var Info = JSON.parse(JSON.stringify(this.RenteShareInfo));
				//Update Last Tab Model Data 
				this.FormInfo[this.LastTab].Vertnr = Info.VERTRAG_NUMBER;
				this.FormInfo[this.LastTab].Flag3 = Info.AVWL === true ? 'X' : '';;
				this.FormInfo[this.LastTab].Votop = Info.SEL_BETRAG_KEY;
				this.FormInfo[this.LastTab].Zuvbu = Info.CHK_BERUF === true ? 'X' : '';
				this.FormInfo[this.LastTab].Zuvhv = Info.CHK_HINTER === true ? 'X' : '';
				this.FormInfo[this.LastTab].Flag4 = Info.RDIO_JAHR === 1 ? true : false;
				this.FormInfo[this.LastTab + "_TAB"] = Info.TABLE_DATA;
				this._TableConvertToStruc(FormInfo, this.FormInfo[this.LastTab + "_TAB"]);
			}
			this.LastTab = TabSelected;
			//Update Current Tab Model Data
			this.RenteShareInfo.SUBTYPE = FormInfo.Subtype;
			this.RenteShareInfo.VERTRAG_NUMBER = FormInfo.Vertnr;
			this.RenteShareInfo.TABLE_DATA = JSON.parse(JSON.stringify(this.FormInfo[TabSelected + "_TAB"]));
			this.RenteShareInfo.AVWL = FormInfo.Flag3 === 'X' || FormInfo.Flag3 === true || FormInfo.Flag3 === 'true' ? true : false;
			this.RenteShareInfo.AVWL_DATE = FormInfo.Avwld;
			this.RenteShareInfo.SEL_BETRAG_KEY = FormInfo.Votop;
			this.RenteShareInfo.CHK_BERUF = FormInfo.Zuvbu === 'X' || FormInfo.Zuvbu === true || FormInfo.Zuvbu === 'true' ? true : false;
			this.RenteShareInfo.CHK_HINTER = FormInfo.Zuvhv === 'X' || FormInfo.Zuvhv === true || FormInfo.Zuvhv === 'true' ? true : false;
			this.RenteShareInfo.RDIO_JAHR = FormInfo.Flag4 === 'X' || FormInfo.Flag4 === true || FormInfo.Flag4 === 'true' ? 1 : 0;
			if ( this.RenteShareInfo.AVWL === true && this.RenteShareInfo.AVWL_ACTIVE === true ){
				this.RenteShareInfo.AVWL_ACTIVE = false;
			}
			this.getView().getModel("Global").setProperty("/Mode", FormInfo.Flag1 === 'false' || FormInfo.Zuvhv === false ? 'M' : 'D');
			sRenteModel.setData(this.RenteShareInfo);

		},
		onAnderungenVerwerfenPress: function(oV) {
			var _ = this;
			MessageBox.confirm(oV.getSource().getText() + "?", {
				styleClass: "sapUiSizeCompact",
				onClose: function(sAction) {
					if (sAction === MessageBox.Action.OK) {						
						_.LastTab = "INFO";
						_.updateRenteData(_.getView().byId("Tabs").getSelectedKey());
					}
				}
			});
		},
		handleMessagePopover: function(oEvent) {
			if (!this.oMP) {
				this.createMessagePopover();
			}
			this.oMP.toggle(oEvent.getSource());
		},

		createMessagePopover: function() {
			var that = this;

			this.oMP = new MessagePopover({
				items: {
					path: "message>/",
					template: new MessageItem({
						title: "{message>message}",					
						type: "{message>type}",
						subtitle: "{message>code}"
					})
				}
			});

			this.oMP._oMessageView.setGroupItems(true);
			this.getView().addDependent(this.oMP);
		},
		onPrufenPress: function(oEvent) {
			sap.ui.getCore().getMessageManager().removeAllMessages();
			this.GlobalData.BusyMode = true;
			var that = this;
			var Info = JSON.parse(JSON.stringify(this.RenteShareInfo));
			//Update Model Data 
			this.FormInfo[this.GlobalData.SelectedTab].Vertnr = Info.VERTRAG_NUMBER;
			this.FormInfo[this.GlobalData.SelectedTab].Flag3 = Info.AVWL + "";
			this.FormInfo[this.GlobalData.SelectedTab].Flag4 = Info.RDIO_JAHR == 1 ? true : false + "";
			this.FormInfo[this.GlobalData.SelectedTab].Votop = Info.SEL_BETRAG_KEY;
			this.FormInfo[this.GlobalData.SelectedTab].Zuvbu = Info.CHK_BERUF + "";
			this.FormInfo[this.GlobalData.SelectedTab].Zuvhv = Info.CHK_HINTER + "";
			this.FormInfo[this.GlobalData.SelectedTab + "_TAB"] = Info.TABLE_DATA;
			this._TableConvertToStruc(this.FormInfo[this.GlobalData.SelectedTab], this.FormInfo[this.GlobalData.SelectedTab + "_TAB"]);
			let sum = 0;
			for (let i = 0; i < 12; i++) {
				sum = Number(sum) + Number(this.RenteShareInfo.TABLE_DATA[i].VOTUM);
			}
			this.RenteShareInfo.TABLE_DATA[12].VOTUM = sum.toFixed(3);
			this.getView().getModel("Rente").setProperty("/TABLE_DATA/12/VOTUM", sum.toFixed(3));

			var sData = JSON.parse(JSON.stringify(this.FormInfo[this.GlobalData.SelectedTab])),
				sPath =
				`RiesterEichelSet(EmployeeNo='${sData.EmployeeNo}',Subtype='${sData.Subtype}',EndDate=datetime'${sData.EndDate}',BeginDate=datetime'${sData.BeginDate}')`;
			delete sData.__metadata;

			this.oDataModel.update(sPath, sData, {
				success: function(R) {
					that.GlobalData.BusyMode = false;
					MessageToast.show(that.oI18n.getText("MSG_SAVED"));
					that._getReisterEichelData();
				},
				error: function(E) {
					if (E && E.response && E.response.body) {											
						var data = that.xmlToJson(new DOMParser().parseFromString(E.response.body, 'text/xml'))
						.error.innererror.errordetails.errordetail;
						if (Array.isArray(data)){
						data.forEach(function(oMessage) {
							that._MessageManager.addMessages(
								new Message({
									message: oMessage.message,
									type: that.formatMessageType(oMessage.severity),
									code: oMessage.code
								})
							);
						});
						}else{
							that._MessageManager.addMessages(
								new Message({
									message: data.message,
									type: that.formatMessageType(data.severity),
									code: data.code
								})
							);
						}
						that.handleMessagePopover(oEvent);
						//var tmp = document.createElement("DIV");
						//tmp.innerHTML = E.response.body;
						//MessageToast.show(tmp.textContent || tmp.innerText || "");
						that._getReisterEichelData();						
					} else {
						MessageToast.show(that.oI18n.getText("ErrorData"));
					}
					that.GlobalData.BusyMode = false;
				}
			});
		},
		formatMessageType: function(E) {
			switch (E) {
				case 'error':
					return MessageType.Error;
				case 'warning':
					return MessageType.Warning;
				default:
					return MessageType.None;
			}
		},
		formatVoteType: function(T) {
			if (T && T !== "") {
				return this.oI18n.getText("VOTE_" + T);
			} else {
				return "";
			}
		},
		formatMonatText: function(M) {
			if (M && M > 0 && M <= 13) {
				return M === "13" ? this.oI18n.getText("TOTAL_HTML", this.GlobalData.TotalColor).replace("@@", this.oI18n.getText("MONTH" + M)) :
					this.oI18n.getText("MONTH" + M);
			} else {
				return "";
			}
		},
		formatAmount: function(A,C){
			if ( A && A !== null ){
				var a = this.oCurrencyFormat.format(A,C);
				return a === '0,00 EUR' ? "---,--" : a;				
			} else {
				return "";
			}
		},
		formatDate: function(D){
			if(this && D && D !== null ){
					return this.oDateFormat.format(new Date(D));
			}else{
				return "";
			}
		},
		_TableConvertToStruc: function(Struc, Table) {
			for (let i = 1; i < 13; i++) {
				let M = i < 10 ? "0" + i : i + "";
				let j = i - 1;
				Struc["Vot" + M] = Table[j].VOTUM;
				Struc["Abr" + M] = Table[j].EIGENANTEIL;
				Struc["Avwl" + M] = Table[j].ARBEITGEBERANTEIL;
				Struc["Eff" + M] = Table[j].PENSIONSKASSE;
			}
		},
		_StrucConvertToTable: function(Data) {

			var ConvertedData = [];
			if (Data && Data !== 'undefined') {
				for (let i = 1; i <= 13; i++) {
					let M = i < 10 ? "0" + i : i + "";
					ConvertedData.push({
						MONAT: M,
						VOTUM: Data["Vot" + M],
						EIGENANTEIL: Data["Abr" + M],
						ARBEITGEBERANTEIL: Data["Avwl" + M],
						PENSIONSKASSE: Data["Eff" + M],
						CURRENCY: Data.Waers
					});
				}
			}
			return ConvertedData;
		},
		xmlToJson: function(xml) {
			// Create the return object
			var obj = {};

			if (xml.nodeType == 1) {
				// element
				// do attributes
				if (xml.attributes.length > 0) {
					obj["@attributes"] = {};
					for (var j = 0; j < xml.attributes.length; j++) {
						var attribute = xml.attributes.item(j);
						obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
					}
				}
			} else if (xml.nodeType == 3) {
				// text
				obj = xml.nodeValue;
			}

			// do children
			// If all text nodes inside, get concatenated text from them.
			var textNodes = [].slice.call(xml.childNodes).filter(function(node) {
				return node.nodeType === 3;
			});
			if (xml.hasChildNodes() && xml.childNodes.length === textNodes.length) {
				obj = [].slice.call(xml.childNodes).reduce(function(text, node) {
					return text + node.nodeValue;
				}, "");
			} else if (xml.hasChildNodes()) {
				for (var i = 0; i < xml.childNodes.length; i++) {
					var item = xml.childNodes.item(i);
					var nodeName = item.nodeName;
					if (typeof obj[nodeName] == "undefined") {
						obj[nodeName] = this.xmlToJson(item);
					} else {
						if (typeof obj[nodeName].push == "undefined") {
							var old = obj[nodeName];
							obj[nodeName] = [];
							obj[nodeName].push(old);
						}
						obj[nodeName].push(this.xmlToJson(item));
					}
				}
			}
			return obj;
		}
	});
});

// 	VOT02
// ABR02
// ABRSV02
// AVWL02
// AVWLSV02
// EFF02
// "0.Dynamic Parameters set by Admin to use in Logic
// "1.For Employees, Edit Just Number of Working Dates after End Of Last Month
// "2.For Admins, Edit Just Numbeer Of Days Before Next Payroll Date Start
// "3.For All, Edit Just untill  Deadline Date in Year
// "4.For All, If PapierVotom is Checked, Just Display. No editing.

//  required Fields: PERNR,BEGDA,ENDDA
//       REART(Art der Wandlung)
//       DNTLT(Dienstleister)
//       VERTNR(Vertragsnummer)
//       VOTOP(RE Votumsoption)
//       AVWLD( AVWL gewählt ab )
//       ZUVBU(Berufsunfähigkeit)
//       ZUVHV(Hinterbliebenen-Versorgung)
//       KEPAP(Papiervotum)
//       WAERS(Currency)
// SUM_VOTUM,SUM_ABR_MAIN,SUM_ABR_AVWL,SUM_EFFBT
// VOT01-VOT12,ABR01-ABR12,AVWL01-AVWL12,EFF01-EFF12